$(document).ready(function() {
    // put your jQuery code here
});